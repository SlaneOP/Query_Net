
  # Academic Q&A Platform UI

  This is a code bundle for Academic Q&A Platform UI. The original project is available at https://www.figma.com/design/RoYRpYGOTk5jJTV1s3q4bf/Academic-Q-A-Platform-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  